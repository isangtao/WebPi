#!/bin/sh

# Re-run only this part to repackage 
cp llamafile-0.10.6 LocalVault9B.exe
./z -j0 LocalVault9B.exe Qwen3.5-9B-Q5_K_S.gguf .args
./z -0 LocalVault9B.exe public/*.html
