# Create a public folder and copy any interesting webpages there along with WebPi.html. Ensure that you have an index.html page that lists all the files.

# Uncomment the following if you need zipalign
# git clone https://github.com/jart/zipalign
# cd zipalign
# make
# cp zipalign ../z
# cd ..

# Download the 0.10.6 launcher release
wget https://github.com/mozilla-ai/llamafile/releases/download/0.10.6/llamafile-0.10.6
chmod +x llamafile-0.10.6

# Download the raw GGUF weights (Adjust the URL if sourcing directly from Hugging Face)
wget https://huggingface.co/unsloth/Qwen3.5-4B-GGUF/resolve/main/Qwen3.5-4B-Q5_K_S.gguf

# For 9B, search all Qwen3.5-4B-Q5_K_S.gguf replace with Qwen3.5-9B-Q5_K_S.gguf. Then the line above with:
# wget https://huggingface.co/unsloth/Qwen3.5-9B-GGUF/resolve/main/Qwen3.5-9B-Q5_K_S.gguf

# Create the local .args configuration file
cat << 'EOF' > .args
-m
/zip/Qwen3.5-4B-Q5_K_S.gguf
-c
32768
--cache-type-k
q4_0
--cache-type-v
q4_0
-ngl
999
--server
--tools
all
--host
0.0.0.0
--port
1234
--cors-origins
"*"
--path
/zip/public
EOF

# Re-run only this part to repackage 
cp llamafile-0.10.6 SovereignFort.exe
./z -j0 SovereignFort.exe Qwen3.5-4B-Q5_K_S.gguf .args
./z -0 SovereignFort.exe public/*.html

# If SovereignFort.exe doesn't fit on your GPU, reduce context and/or number of GPU layers. e.g. -c 16384 -ngl 10
