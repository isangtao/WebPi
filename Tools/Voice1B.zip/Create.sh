#!/bin/sh

# Uncomment the following if you need zipalign
# git clone https://github.com/jart/zipalign
# cd zipalign
# make
# cp zipalign ../z
# cd ..

# Download the 0.10.6 launcher release
wget https://github.com/mozilla-ai/llamafile/releases/download/0.10.6/llamafile-0.10.6
chmod +x llamafile-0.10.6

# Download the raw GGUF weights (Adjust the URL if sourcing directly from Hugging Face)
wget https://huggingface.co/unsloth/gemma-3-1b-it-GGUF/resolve/main/gemma-3-1b-it-UD-Q4_K_XL.gguf

# Create the local .args configuration file
cat << 'EOF' > .args
-m
/zip/gemma-3-1b-it-UD-Q4_K_XL.gguf
--reasoning-budget
0
--reasoning
off
--chat-template-kwargs
'{"enable_thinking":false}'
-c
16384
--cache-type-k
q4_0
--cache-type-v
q4_0
-ngl
999
--server
--tools
all
--host
0.0.0.0
--port
1234
--cors-origins
"*"
--path
/zip/public
EOF

# Re-run only this part to repackage 
cp llamafile-0.10.6 Voice1B.exe
./z -j0 Voice1B.exe gemma-3-1b-it-UD-Q4_K_XL.gguf .args
./z -0 Voice1B.exe public/*.html

# If the file doesn't fit on your GPU, reduce context and/or number of GPU layers. e.g. -c 16384 -ngl 10
