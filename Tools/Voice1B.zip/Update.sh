#!/bin/sh

# Re-run only this part to repackage 
cp llamafile-0.10.6 Voice1B.exe
./z -j0 Voice1B.exe gemma-3-1b-it-UD-Q4_K_XL.gguf .args
./z -0 Voice1B.exe public/*.*
# If the file doesn't fit on your GPU, reduce context and/or number of GPU layers. e.g. -c 16384 -ngl 10
