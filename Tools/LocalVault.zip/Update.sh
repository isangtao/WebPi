#!/bin/sh

# Re-run only this part to repackage 
cp llamafile-0.10.6 LocalVault.exe
./z -j0 LocalVault.exe Qwen3.5-4B-Q5_K_S.gguf .args
./z -0 LocalVault.exe public/*.html

# If SovereignFort.exe doesn't fit on your GPU, reduce context and/or number of GPU layers. e.g. -c 16384 -ngl 10
