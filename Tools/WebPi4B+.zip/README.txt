git clone https://github.com/jart/zipalign
cd zipalign
make
# Copy the compiled binary out to your working directory
cp zipalign ../
cd ..

# Download the 0.10.6 launcher release
wget https://github.com/mozilla-ai/llamafile/releases/download/0.10.6/llamafile-0.10.6

# Download the raw GGUF weights (Adjust the URL if sourcing directly from Hugging Face)
wget https://huggingface.co -O Qwen3.5-2B-Q8_0.gguf

# Add custom webpage
mkdir public
copy WebPi.html to folder and rename to index.html

# Create the local .args configuration file
cat << 'EOF' > .args
-m
/zip/Qwen3.5-4B-Q5_K_S.gguf
-c
32768
--cache-type-k
f16
--cache-type-v
f16
-ngl
999
--server
--tools
all
--host
0.0.0.0
--port
1234
--cors-origins
"*"
--path
/zip/public
EOF

chmod +x llamafile-0.10.6
cp llamafile-0.10.6 WebPi4B
./zipalign -j0 WebPi4B Qwen3.5-4B-Q5_K_S.gguf .args
./zipalign -0 WebPi4B public/*.html




