# Create a public folder and copy any interesting webpages there along with WebPi.html. Ensure that you have an index.html page that lists all the files.

git clone https://github.com/jart/zipalign
cd zipalign
make
# Copy the compiled binary out to your working directory
cp zipalign ../z
cd ..

# Download the 0.10.6 launcher release
wget https://github.com/mozilla-ai/llamafile/releases/download/0.10.6/llamafile-0.10.6
chmod +x llamafile-0.10.6

# Download the raw GGUF weights (Adjust the URL if sourcing directly from Hugging Face)
wget https://huggingface.co/unsloth/Qwen3.5-9B-GGUF/resolve/main/Qwen3.5-9B-Q5_K_S.gguf

# Create the local .args configuration file
cat << 'EOF' > .args
-m
/zip/Qwen3.5-9B-Q5_K_S.gguf
-c
32768
--cache-type-k
q4_0
--cache-type-v
q4_0
-ngl
999
--server
--tools
all
--host
0.0.0.0
--port
1234
--cors-origins
"*"
--path
/zip/public
EOF

# Re-run only this part to repackage 
cp llamafile-0.10.6 WebPi9B
./z -j0 WebPi9B Qwen3.5-9B-Q5_K_S.gguf .args
./z -0 WebPi9B public/*.html

