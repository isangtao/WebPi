#!/bin/sh

# Re-run only this part to repackage 
cp llamafile-0.10.6 LocalVault4B.exe
./z -j0 LocalVault4B.exe Qwen3.5-4B-Q5_K_S.gguf .args
./z -0 LocalVault4B.exe public/*.html

# If the file doesn't fit on your GPU, reduce context and/or number of GPU layers. e.g. -c 16384 -ngl 10
